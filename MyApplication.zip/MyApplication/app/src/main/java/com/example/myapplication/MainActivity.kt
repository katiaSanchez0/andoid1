package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.android.volley.AuthFailureError
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity(), View.OnClickListener {
    var imageView: ImageView? = null
    var btnTake: Button? = null
    var btnUpload: Button? = null
    var currentePhoto: String? = null
    var decode: Bitmap? = null
    var et: EditText? = null
    var KEY_NOMBRE = "nombre"
    var requestQueue: RequestQueue? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initUi()
        requestQueue = Volley.newRequestQueue(this)
        btnTake!!.setOnClickListener(this)
        btnUpload!!.setOnClickListener(this)
    }

    private fun initUi() {
        imageView = findViewById(R.id.imgPhoto)
        btnTake = findViewById(R.id.btnTakePicture)
        btnUpload = findViewById(R.id.btnUploadImage)
        et = findViewById(R.id.txtLl_rpe2)
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val image = File.createTempFile(
            imageFileName,
            ".jpg",
            storageDir
        )
        currentePhoto = image.absolutePath
        return image
    }

    private fun takePictureFullSize() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) {
            var photoFile: File? = null
            try {
                photoFile = createImageFile()
            } catch (e: IOException) {
                e.message
            }
            if (photoFile != null) {
                val photoUri = FileProvider.getUriForFile(
                    this,
                    "com.example.camara",
                    photoFile
                )
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                startActivityForResult(intent, REQUEST_TAKE_PHOTO)
            }
        }
    }

    private fun checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                takePictureFullSize()
            } else {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.CAMERA),
                    REQUEST_PERMISSION_CAMERA
                )
            }
        } else {
            takePictureFullSize()
        }
    }

    private fun setToImageView(bitmap: Bitmap) {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        decode = BitmapFactory.decodeStream(ByteArrayInputStream(bytes.toByteArray()))
        imageView!!.setImageBitmap(decode)
    }

    private fun getResizedBitmap(bitmap: Bitmap, maxSize: Int): Bitmap {
        var width = bitmap.width
        var height = bitmap.height
        if (width <= maxSize && height <= maxSize) {
            return bitmap
        }
        val bitmapRadio = width.toFloat() / height.toFloat()
        if (bitmapRadio > 1) {
            width = maxSize
            height = (width / bitmapRadio).toInt()
        } else {
            height = maxSize
            width = (height * bitmapRadio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }

    private fun getStringImage(bitmap: Bitmap?): String {
        val baos = ByteArrayOutputStream()
        bitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val imageBytes = baos.toByteArray()
        return Base64.encodeToString(imageBytes, Base64.DEFAULT)
    }

    private fun uploadImage() {
        val URL = "http://10.4.57.12/ssman_movil/upload.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST,
            URL,
            Response.Listener {
                Toast.makeText(this@MainActivity, "Correcto", Toast.LENGTH_SHORT).show()
            },
            Response.ErrorListener { }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String>? {
                val nombre = et!!.text.toString().trim { it <= ' ' }
                val params: MutableMap<String, String> = HashMap()
                params["path"] = getStringImage(decode)
                params[KEY_NOMBRE] = nombre + 1
                return params
            }
        }
        requestQueue!!.add(stringRequest)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        if (requestCode == REQUEST_PERMISSION_CAMERA) {
            if (permissions.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                takePictureFullSize()
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_TAKE_PHOTO) {
            if (resultCode == RESULT_OK) {
                try {
                    val file = File(currentePhoto)
                    val uri = Uri.fromFile(file)
                    val bitmap = MediaStore.Images.Media.getBitmap(
                        this.contentResolver,
                        uri
                    )
                    setToImageView(getResizedBitmap(bitmap, 1024))
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onClick(view: View) {
        val id = view.id
        if (id == R.id.btnTakePicture) {
            checkPermission()
        } else if (id == R.id.btnUploadImage) {
            uploadImage()
        }
    }

    companion object {
        const val REQUEST_PERMISSION_CAMERA = 100
        const val REQUEST_TAKE_PHOTO = 101
    }
}
